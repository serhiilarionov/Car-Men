<?php

namespace Modules\News\Http\Controllers;

use InfyOm\Generator\Utils\ResponseUtil;
use App\Http\Controllers\AppBaseController as BaseController;
use Response;

class AppBaseController extends BaseController
{

}
