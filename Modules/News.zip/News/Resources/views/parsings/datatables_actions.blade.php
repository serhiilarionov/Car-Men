<div class='btn-group'>
    <a href="{{ route('news.parsingDetails.index', ['day' => $day]) }}" class='btn btn-default btn-xs'>
        <i class="glyphicon glyphicon-eye-open"></i>
    </a>
</div>
