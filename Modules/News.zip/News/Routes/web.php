<?php

Route::resource('articles', 'ArticleController');
Route::resource('parsings', 'ParsingController');
Route::resource('parsingDetails', 'ParsingDetailController');